const axios = require('axios');
const WebSocket = require('ws');
const { StartFastHttp } = require('fasthttp');


const token = 'acc token';
const guid = 'server id'; 
const password = 'acc pass'; 
const targets = {
    'server id': 'your vanity',
};
StartFastHttp();
async function fetchBuildnum() {
    try {
        const response = await axios.get('https://discord.com/login');
        const buildNumberMatch = response.data.match(/build_number:"(\d+)"/);
        return buildNumberMatch ? buildNumberMatch[1] : null;
    } catch (error) {
        console.error('Error fetching build number:', error);
        return null;
    }
}

async function mfa(token, tim, cookies) {
    const url = 'https://discord.com/api/v9/mfa/finish';
    const headers = {
        'Authorization': token,
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    };
    const payload = {
        ticket: tim,
        mfa_type: 'password',
        data: password,
    };

    try {
        const response = await axios.post(url, payload, { headers, cookies });
        const { token, __Secure_recent_mfa } = response.data;
        return { token, __Secure_recent_mfa };
    } catch (error) {
        console.error('Error during MFA request:', error);
        return null;
    }
}

async function changeVanity(vanityCode) {
    const url = `https://discord.com/api/v9/guilds/${guid}/vanity-url`;
    const headers = {
        'Authorization': token,
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    };
    const payload = { code: vanityCode };

    try {
        const response = await axios.patch(url, payload, { headers });
        if (response.status === 200) {
            console.log(`Successfully sniped vanity code: ${vanityCode}`);
            return true;
        }
        if (response.data.mfa) {
            const { ticket } = response.data.mfa;
            const cookies = response.headers['set-cookie'];
            const { token, __Secure_recent_mfa } = await mfa(token, ticket, cookies);
            if (token) {
                headers['x-discord-mfa-authorization'] = token;
                headers['__Secure-recent_mfa'] = __Secure_recent_mfa;
                const retryResponse = await axios.patch(url, payload, { headers });
                if (retryResponse.status === 200) {
                    console.log(`Successfully sniped vanity code after MFA: ${vanityCode}`);
                    return true;
                }
            }
        }
        console.error('Failed to change vanity URL');
        return false;
    } catch (error) {
        console.error('Error changing vanity:', error);
        return false;
    }
}

async function startWebSocket() {
    const ws = new WebSocket('wss://gateway.discord.gg/?encoding=json&v=9');
    ws.on('open', () => {
        console.log('WebSocket connection established');
        const presence = {
            op: 2,
            d: {
                token: token,
                capabilities: 30717,
                properties: {
                    os: 'Windows',
                    browser: 'Chrome',
                    device: 'Desktop',
                    system_locale: 'en-US',
                    browser_user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
                    browser_version: '117.0.0.0',
                    os_version: '10',
                    referrer: '',
                    referring_domain: '',
                    release_channel: 'stable',
                    client_build_number: 123456,
                },
                presence: {
                    afk: false,
                    since: Date.now(),
                    activities: [{ name: 'drugNS3x', type: 0 }],
                    status: 'online',
                },
                compress: false,
            },
        };
        ws.send(JSON.stringify(presence));
    });

    ws.on('message', (data) => {
        const event = JSON.parse(data);
        if (event.op === 10) {
            const heartbeatInterval = event.d.heartbeat_interval / 1000;
            setInterval(() => ws.send(JSON.stringify({ op: 1, d: event.s })), heartbeatInterval);
        }
        if (event.t === 'GUILD_UPDATE') {
            if (targets[event.d.id] && targets[event.d.id] !== event.d.vanity_url_code) {
                changeVanity(targets[event.d.id]);
            }
        }
    });
}

(async () => {
    try {
        const buildNumber = await fetchBuildnum();
        console.log('Fetched build number:', buildNumber);
        await startWebSocket();
    } catch (error) {
        console.error('Error starting WebSocket:', error);
    }
})();
